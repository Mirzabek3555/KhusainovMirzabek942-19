<?php
    header('location: html/index-2.php');