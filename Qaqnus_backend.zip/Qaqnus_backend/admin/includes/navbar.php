
<?php 
include 'header.php';
 ?>

<nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
  <a class="navbar-brand text-white" href="#">Qaqnus Academy</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto ">
      <li class="nav-item active">
        <a class="nav-link text-white" href="../../">Home <span class="sr-only">(current)</span></a>
     <!--  </li>
      <li class="nav-item">
        <a class="nav-link text-white" href="#">Link</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Dropdown
        </a>
        <div class="dropdown-menu text-white" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Disabled</a>
      </li> -->
    </ul>
   <!--  <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form> -->
  </div>
</nav>













<div class="row">     <!--  second row closed -->

<div class="col-md-12">    <!-- list of users starts -->
<form action="http://localhost/Qaqnus_backend/admin/admin_main.php/" method="POST">
  <table class="table ml-5 bg-white shodow pl-5 table-responsive" style=" height : 355px;overflow-y: scroll;display: inline-block; width: 1000%;"> 
    
   <!-- table stsrts  -->  <!--  use table-responsive class -->
  <p class="ml-5">Foydalanuvchilar ro'yhati </p>

  <thead>
    <tr>
  
      <th scope="col">id</th>
      <th scope="col">Username</th>
      <th scope="col">Password</th>
      <th scope="col">email id</th>
      <th scope="col">Iqtisod</th>
      <th scope="col">Sog'lik</th>
      <th scope="col">Munosabat</th>
      <th scope="col">Sh.Rivoj</th>
    </tr>
  </thead>
  <tbody style="">

     <?php
      die(
        '234234324324324'
      );
        foreach ($userd as $userdata):
          die('sadasdsdsad');   
     ?> 
    <tr >
      <input type="hidden" name="id" value="$userdata['id']">
      <th scope="row"><?php echo $userdata['id']; ?></th>
      <td ><?php echo $userdata['username']; ?></td>
      <td><?php echo $userdata['password']; ?></td>
      <td><?php echo $userdata['email']; ?></td>
      <td>
         <select name="kurs_1" id="">
        <option value="0">Modul_1</option>
        <option value="1">Modul_2</option>
      </select>
        </td>
      <td>
        <select name="kurs_2" id="">
        <option value="0">Modul_1</option>
        <option value="1">Modul_2</option>
      </select>
    </td>
      <td>
        <select name="kurs_3" id="">
        <option value="0">Modul_1</option>
        <option value="1">Modul_2</option>
      </select>
    </td>
      <td>
        <select name="kurs_4" id="">
        <option value="0">Modul_1</option>
        <option value="1">Modul_2</option>
      </select>
    </td>
      
    </tr>
   
   <?php endforeach; ?>
  </tbody>
</table>
<button name="dostup">O'zgarishni saqlash</button>
</form>

  <!-- table ends  -->



</div>   <!-- list of users ends -->

