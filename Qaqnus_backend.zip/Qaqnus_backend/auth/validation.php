<?php
	require "../database/connection.php";
	
	mysqli_select_db($con, $database);
	$username=$_POST['username'];
	$pass=$_POST['password'];
	
	$q="select * from login where username='$username' && password='$pass'";
	
	$result = mysqli_query($con, $q);
	$res = mysqli_fetch_assoc($result);
	$num = mysqli_num_rows($result);
	// die("validation 13");
	
	session_start();
	if ($num == 1) {
		$_SESSION['role'] = $res['role'];
		$_SESSION['username'] = $username;

		switch ($_SESSION['role']) {   
			 // student
			 case 1:
                header('location: ../html/courses.php') ; 
                break;       
            case 0:   // admin
                header('location:../admin_panel/admin_page.php');
                break;
            default:   // login page
                header('location:../login.php');
                break;	
		}  } else {
		$_SESSION['error']="error";
		header('location:login.php');
	}
?>