<?php
    session_start();
    if (isset($_SESSION['role'])) {
        $role = $_SESSION['role'];

        switch ($role) { 
          // student
            case 1:
          
                header('location: ../courseVideos/courseVideo.php') ; 
                break;       
            case 0:   // admin
                header('location:../admin_panel/admin_page.php');
                break;
            default:   // login page
                header('location:../login.php');
                break;
        }
    }
   