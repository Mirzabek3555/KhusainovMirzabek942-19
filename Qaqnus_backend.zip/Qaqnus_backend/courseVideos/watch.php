<?php
$connect = mysqli_connect("localhost", "root", "", "qaqnusakademy");
require "../database/connection.php";
mysqli_select_db($con, $database);

if (isset($_GET['id'])){
    $id = $_GET['id'];
$sql = "SELECT name FROM video WHERE id='$id'";

$res = mysqli_query($con,$sql);

while ($row = mysqli_fetch_array($res)){
$name = $row['name'];

echo "<h1> You are watching:".$name." </h1><br/>";
?>

<video width="600" height="316" controls>
        <source src="../admin_panel/videolar/<?php  echo $name; ?> " 
        type="video/mp4">
</video>

<?php
}
}
?>


<script>
									 
        document.onkeydown = function(e) {
                    if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) {
                        alert('not allowed');
                    }
                    return false;
            };
        
        
        
        						$(function() {
            $(this).bind("contextmenu", function(e) {
                e.preventDefault();
            });
        }); 
        
        // Prevent F12      
        $(document).keydown(function (event) {
            if (event.keyCode == 123) { // Prevent F12
                return false;
            } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
                return false;
            }
        });
        
        //stop copy of content
        function killCopy(e){
            return false
        }
        function reEnable(){
            return true
        }
        document.onselectstart=new Function ("return false")
            if (window.sidebar){
            document.onmousedown=killCopy
            document.onclick=reEnable
        }
        
        // prevent ctrl + s
        $(document).bind('keydown', function(e) {
          if(e.ctrlKey && (e.which == 83)) {
            e.preventDefault();
            return false;
          }
        });
 </script>



<script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/vendor/holder.min.js"></script>
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script> 

