<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "qaqnusakademy");
require "../database/connection.php";
mysqli_select_db($con, $database);

?>
<!DOCTYPE html> 
<html>
  <head>
    <title>Qaqnus Academy</title>
 <meta charset="utf-8">
    </head>
    <body>

 <?php
 
 $course_id = $_GET['course'];
 $type = $_GET['type'];
 $username = $_SESSION['username'];

 // type = 0 bo'lsa pullik kurslar, 1 bo'lsa bepul kurslar 
 if ($type == 1){

	 $query0 = "SELECT * FROM video WHERE course_id = '$course_id' and typee = $type ";
	 $reslut0 = mysqli_query($connect , $query0);
	 $row0 = mysqli_fetch_array($reslut0);

	
	 
	 Show_Video($reslut0); 
	 // videolarni ko'rsatib beradigan funksiya;

 }  else if ($type == 0) {
	 // type = 0 bo'lsa pullik kurslar bo'ladi 
	 // permission dan olib tekshiradi dostup bor yoki yo'qligini

       $query1 = "SELECT modul FROM permission WHERE username = '$username' and course_id = '$course_id' ";
       $result1 = mysqli_query($connect , $query1);
       $row1 = mysqli_fetch_array($result1);
	  
  
       $modul = $row1['modul'];

       $query2 = "SELECT * FROM video WHERE course_id = '$course_id' AND modul = '$modul' AND typee = '$type' ";
       $result2 = mysqli_query($connect , $query2);
       $row2 = mysqli_fetch_array($result2);
      

       if (isset($row2)){
	         Show_Video($result2);
       } else 
            echo " <h4> Oldin bu kursni harid qilishingiz kerak! </h4> ";
       }
   ?>

  </body>
</html>


<!DOCTYPE html>
<html>
<head>
	<title>Qaqnus Academy</title>
	<!----css file link-->
	<link rel="stylesheet" type="text/css" href="../../csss/programming.css">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!----Linking google fonts-->
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<!----font-awsome start-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


	<style type="text/css">
		.bgcolor
		{   background: rgba(0,0,0,0.1);   }
        body
		{
background: #FC354C;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #0ABFBC, #FC354C);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #0ABFBC, #FC354C); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
		color: white;
		}

		.navbar
		{
			background: #C04848;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #480048, #C04848);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #480048, #C04848); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

		}
	</style>
</head>
<body>

			<!---Navigation Starts	----->
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container ">
			<div class="navbar-header col-sm-11">
				
				<h1 style="color: white;margin-top: 10px;" id="myhead">Qaqnus Academy</h1>
			</div>
			<div class="col-md-1 ">
				<br><br>
				<a href="../html/courses.php" class="btn btn-warning" role="button">Kurslarga qaytish</a>	</div>
		</div>
	</nav>
			<!---Navigation Ends	----->

 			<!---programming languages Section Start	----->
<br><br><br>
 			<section class="latest-news-area" id="latest">
 				<div class="container">
 					<div class="row">
 						<div class="col-xs-12">
 							<div class="section-title text-center">
 								<h2><b>   
                                      <?php

										  switch ($course_id){

                                                case 1  : 
													print_r("Moliya darslari");
													break;
												case 2: 
													print_r("Sog'lik darslari");
													break;
												case 3: 
													print_r("Munosabatlar");
													break;
												case 4:
													print_r("Shaxsiy rivojlanish");
											   }
									  ?>   </b></h2>
 							</div>
 						</div>
 					</div>

 					<div class="row">
 						<div class="news-active">
 							<div class="col-md-4 col-sm-6 col-xs-12 content-border" >
 								<div class="bgcolor latest-news-wrap " >
 									

 										<div class="deat">
 											<span>Modul-1</span>	
											 <?php
								    	function Show_Video($res){
                                           if (isset($res)){
											   while ($row = mysqli_fetch_assoc($res)) {
											   
                                                  $id = $row['id'];
												  $name = $row['name'];
												  ?>
                            	
                                             <div class = "news-active" style = "margin:40px; margin-left:150px;" >
                                                <?php
												   echo "<h4> <a href='watch.php?id=$id' > ".  $name .  "</a></h4>";
												?>
											 </div>
                                                      
												<?php
												}  
											}  else { 
											    echo "<h1> Oldin bu kursni harid qilishingiz kerak!  </h1>";
											}
										}
										
								 ?>
                                  </div>
 									
 								</div>
 							</div>

 							<div class="col-md-4 col-sm-6 col-xs-12 content-border">
 								<div class="bgcolor latest-news-wrap">
 									<div class="news-img">
 									
 										<div class="deat">
 											<span>Modul - 2</span>
 										</div>
										 <br><br><br> <br><br>
 									</div>
                                     <br><br><br><br>									</div>
 								</div>
 							</div>
 						</div>
						  
						 

								 
 					</div> 
 				</div>
											
 			</section>
			

   <script>
									 
        document.onkeydown = function(e) {
                    if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) {
                        alert('not allowed');
                    }
                    return false;
            };
        
        
        
        						$(function() {
            $(this).bind("contextmenu", function(e) {
                e.preventDefault();
            });
        }); 
        
        // Prevent F12      
        $(document).keydown(function (event) {
            if (event.keyCode == 123) { // Prevent F12
                return false;
            } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
                return false;
            }
        });
        
        //stop copy of content
        function killCopy(e){
            return false
        }
        function reEnable(){
            return true
        }
        document.onselectstart=new Function ("return false")
            if (window.sidebar){
            document.onmousedown=killCopy
            document.onclick=reEnable
        }
        
        // prevent ctrl + s
        $(document).bind('keydown', function(e) {
          if(e.ctrlKey && (e.which == 83)) {
            e.preventDefault();
            return false;
          }
        });
 </script>


<script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/vendor/holder.min.js"></script>
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>             
</body>
</html>