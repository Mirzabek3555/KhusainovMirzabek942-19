<?php

session_start();
 if (isset($_SESSION['username'])) {
          $type = $_GET['type'];
          redirect($_GET['course'] , $type);

      } 
else {
     header('location:../auth/login.php');
}
    
 function redirect($course , $type) {
    header("location: ../courseVideos/courseVideo.php?course=$course&type=$type");
 }

   