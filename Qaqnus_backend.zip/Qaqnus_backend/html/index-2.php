<!doctype html>
<html lang="en">

<head>
   
    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!--====== Title ======-->
    <title>Qaqnus Academy </title>
    
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="../images/favicon.png" type="image/png">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="../css/slick.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="../css/animate.css">
    
    <!--====== Nice Select css ======-->
    <link rel="stylesheet" href="../css/nice-select.css">
    
    <!--====== Nice Number css ======-->
    <link rel="stylesheet" href="../css/jquery.nice-number.min.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="../css/magnific-popup.css">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    
    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    
    <!--====== Default css ======-->
    <link rel="stylesheet" href="../css/default.css">
    
    <!--====== Style css ======-->
    <link rel="stylesheet" href="../css/style.css">
    
    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="../css/responsive.css">
  
  
</head>

<body>
    
    <header id="header-part">
        <div class="navigation">
            <div class="container">
                <div class="row">
                    <div class="  ml-50 col-lg-14 col-md-14 col-sm-14 col-14">
                        <nav class="navbar navbar-expand-lg">
                            <a  class="navbar-brand ; " href="#">
                                <img  style="width: 100px; height: 100px;" src="../images/logoo.png" alt="Logo">
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul class="navbar-nav mr-auto">

                                   
                                    <li class="nav-item">
                                        <i class="fa fa-home"></i>
                                        <a class="active" href="index-2.html">Home</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="about.html">Biz Haqimizda</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="courses.php">Kurslar</a>
                                        
                                    </li>
                                    <!-- <li class="nav-item">
                                        <a href="events.html">Hodisalar</a>
                                    </li> -->
                                    <li class="nav-item">
                                        <a href="teachers.html">Bizning Mentorlar</a>
                                    </li>
                                    
                                    
                                    <li class="nav-item">
                                        <a href="contact.php">Kursga Yozilish</a>
                                         
                                    </li>
                                    <li> <a href="" id="our-location" class="btn-success" > <?php if (isset($_SESSION['username'])) { echo $_SESSION['username']; }   ?></a></li>
                                    <li class="nav-item">
                                        <a href="../auth/logout.php">exit</a>
                                         
                                    </li> 
                                </ul>
                            </div>
                        </nav>  
                    </div>
                   
                </div> <!-- row -->
            </div> <!-- container -->
        </div>
        
    </header>
    
    <!--====== HEADER PART ENDS ======-->
   
    <!--====== SEARCH BOX PART START ======-->
    
    <div class="search-box">
        <div class="serach-form">
            <div class="closebtn">
                <span></span>
                <span></span>
            </div>
            <form action="#">
                <input type="text" placeholder="Search by keyword">
                <button><i class="fa fa-search"></i></button>
            </form>
        </div> <!-- serach form -->
    </div>
    
    <!--====== SEARCH BOX PART ENDS ======-->
   
    <!--====== SLIDER PART START ======-->
    
    <section id="slider-part" class="slider-active">
        <div class="single-slider bg_cover pt-150" style="background-image: url(../images/slider/fon.jpg)" data-overlay="4">
            <div class="container">
                <div class="row">
                    <div class="col-xl-7 col-lg-9">
                        <div class="slider-cont">
                            <h1 data-animation="bounceInLeft" data-delay="1s">Ayollar uchun ilmiy maskan!</h1>
                            <p data-animation="fadeInUp" data-delay="1.3s">Qizlarga har tomonlama yordam beruvchi akademiya:</p>
                            <p data-animation="fadeInUp" data-delay="1.3s"> - Moliya</p>
                            <p data-animation="fadeInUp" data-delay="1.3s"> -Munosabatlar  </p>
                            <p data-animation="fadeInUp" data-delay="1.3s"> - Sog'liq</p>
                            <p data-animation="fadeInUp" data-delay="1.3s"> -Shaxsiy rivojlanish</p>
                            <p data-animation="fadeInUp" data-delay="1.3s"> Ushbu sferalarda birgalikda rivojlanamiz!</p>
                                                      
                             
                            <ul>
                                <!-- <li><a data-animation="fadeInUp" data-delay="1.6s" class="main-btn" href="#">Ko'proq bilish</a></li> -->
                                <li><a data-animation="fadeInUp" data-delay="1.9s" class="main-btn main-btn-2" href="courses.php">Boshlash</a></li>
                            </ul>
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- single slider -->
        
        <div class="single-slider bg_cover pt-150" style="background-image: url(../images/slider/fon2.jpg)" data-overlay="4">
            <div class="container">
                <div class="row">
                    <div class="col-xl-7 col-lg-9">
                        <div class="slider-cont">
                            <h1 data-animation="bounceInLeft" data-delay="1s">Maqsadimiz: Muslima ayol-qizlarimizga kerakli, sifatli va sof ilmlarni yetkazish</h1>
                            <!-- <p data-animation="fadeInUp" data-delay="1.3s">Bizda ayollar va qizlar uchun qiziqarli va eng sifatli kurslar mavjud. Hoziroq o'z yo'nalishinggizni tanlang va talim oling.</p> -->
                            <ul>
                                <!-- <li><a data-animation="fadeInUp" data-delay="1.6s" class="main-btn" href="#">Ko'proq Bilish</a></li> -->
                                <li><a data-animation="fadeInUp" data-delay="1.9s" class="main-btn main-btn-2" href="courses.php">Boshlash</a></li>
                            </ul>
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- single slider -->
        
    </section>
    
    <!--====== SLIDER PART ENDS ======-->
   
    <!--====== CATEGORY PART START ======-->
    
    <section id="category-part">
        <div class="container">
            <div class="category pt-40 pb-80">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="category-text pt-60">
                            <h2>Bizning Kurslar</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 offset-lg-1 col-md-8 offset-md-2 col-sm-8 offset-sm-2 col-8 offset-2">
                        <div class="row category-slied mt-40">
                            <div class="col-lg-4">
                                <a href="#">
                                    <span class="singel-category text-center color-1">
                                        <span style="width: 80px; " class="icon">
                                            <img  src="../images/slider/finan.png" alt="Icon">
                                        </span>
                                        <span class="cont">
                                            <span>Moliya</span>
                                        </span>
                                    </span> <!-- singel category -->
                                </a>
                            </div>
                            <div class="col-lg-4">
                                <a href="#">
                                    <span class="singel-category text-center color-2">
                                        <span style="width: 80px;" class="icon">
                                            <img src="../images/all-icon/medic.png" alt="Icon">
                                        </span>
                                        <span class="cont">
                                            <span>Sog'liq</span>
                                        </span>
                                    </span> <!-- singel category -->
                                </a>
                            </div>
                            <div class="col-lg-4">
                                <a href="#">
                                    <span class="singel-category text-center color-3">
                                        <span class="icon">
                                            <img style="width: 80px;" src="../images/all-icon/law.png" alt="Icon">
                                        </span>
                                        <span class="cont">
                                            <span>Huquq</span>
                                        </span>
                                    </span> <!-- singel category -->
                                </a>
                            </div>
                            <div class="col-lg-4">
                                <a href="#">
                                    <span class="singel-category text-center color-1">
                                        <span style="height: 85px;" class="icon">
                                            <img src="../images/all-icon/munosabat.jfif" alt="Icon">
                                        </span>
                                        <span class="cont">
                                            <span>Munosabatlar</span>
                                        </span>
                                    </span> <!-- singel category -->
                                </a>
                            </div>
                            <div class="col-lg-4">
                                <a href="#">
                                    <span class="singel-category text-center color-2">
                                        <span style="width: 55px;" class="icon">
                                            <img src="../images/all-icon/personal.jfif" alt="Icon">
                                        </span>
                                        <span class="cont">
                                            <span>Shaxsiy rivojlanish</span>
                                        </span>
                                    </span> <!-- singel category -->
                                </a>
                            </div>
                            <div class="col-lg-4">
                                <a href="#">
                                    <span class="singel-category text-center color-3">
                                        <span class="icon">
                                            <img src="../images/all-icon/ctg-3.png" alt="Icon">
                                        </span>
                                        <span class="cont">
                                            <span>Psixologiya</span>
                                        </span>
                                    </span> <!-- singel category -->
                                </a>
                            </div>
                        </div> <!-- category slied -->
                    </div>
                </div> <!-- row -->
            </div> <!-- category -->
        </div> <!-- container -->
    </section>
    
    <!--====== CATEGORY PART ENDS ======-->
   
    <!--====== ABOUT PART START ======-->
    
    <section id="about-part" class="pt-65">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="section-title mt-50">
                        <h5>Biz haqimizda</h5>
                        <h2>Qaqnus Academyga xush kelibsiz!</h2>
                    </div> <!-- section title --> <br>
                    <div class="about-cont">
                        <b >Ayollar uchun ilmiy maskan! <br>

                            Maqsadimiz: "Muslima ayol-qizlarimizga kerakli, sifatli va sof ilmlarni yetkazish" <br>
                             Alloh sizlardan iymon keltirganlarni, xususan, ilmga berilganlarni darajalarga ko'tarur. [58:11]</b> <br>
                        <a href="about.html" class="main-btn mt-55">Ko'proq o'qish</a>
                    </div>
                </div> <!-- about cont -->
         
        <div class="about-bg">
            <img style=" filter: drop-shadow(0px 10px 3px black);
    " src="../images/about/shunigor.jfif" alt="About">
        </div>
    </section>
    
    <!--====== ABOUT PART ENDS ======-->
   
    <!--====== APPLY PART START ======-->
    
 <!--   <section id="apply-aprt" class="pb-120">
        <div class="container">
            <div class="apply">
                <div class="row no-gutters">
                    <div class="col-lg-6">
                        <div class="apply-cont apply-color-1">
                            <h3>Apply for fall 2019</h3>
                            <p>Gravida nibh vel velit auctor aliquetn sollicitudirem sem quibibendum auci elit cons equat ipsutis sem nibh id elituis sed odio sit amet nibh vulputate cursus equat ipsutis.</p>
                            <a href="#" class="main-btn">Apply Now</a>
                        </div> apply cont 
                    </div>
                    <div class="col-lg-6">
                        <div class="apply-cont apply-color-2">
                            <h3>Apply for scholarship</h3>
                            <p>Gravida nibh vel velit auctor aliquetn sollicitudirem sem quibibendum auci elit cons equat ipsutis sem nibh id elituis sed odio sit amet nibh vulputate cursus equat ipsutis.</p>
                            <a href="#" class="main-btn">Apply Now</a>
                        </div>  apply cont 
                    </div> 
                </div>
            </div> 
        </div> 
    </section> -->
    
    <!--====== APPLY PART ENDS ======-->
   
    <!--====== COURSE PART START ======-->
    
    
    
    <!--====== COURSE PART ENDS ======-->
   
    <!--====== VIDEO FEATURE PART START ======-->
    
    
    <!--====== VIDEO FEATURE PART ENDS ======-->
   
    <!--====== TEACHERS PART START ======-->
    
   
    
    <!--====== TEACHERS PART ENDS ======-->
   
    <!--====== PUBLICATION PART START ======-->
    
    
    <!--====== PUBLICATION PART ENDS ======-->
   
    <!--====== TEASTIMONIAL PART START ======-->
    
    
    <!--====== TEASTIMONIAL PART ENDS ======-->
   
    <!--====== NEWS PART START ======-->
    
    
    
    <!--====== NEWS PART ENDS ======-->
   
    <!--====== PATNAR LOGO PART START ======-->
    
 
    
    <!--====== PATNAR LOGO PART ENDS ======-->
   
    <!--====== FOOTER PART START ======-->
    
    <footer id="footer-part">
        <div class="footer-top pt-20 pb-40">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-about mt-40">
                            <div class="logo">
                                <!-- <a href="#"><img src="images/logo-2.png" alt="Logo"></a> -->
                            </div>
                            <div class="footer-title pb-25">
                                <h6>Bizni ijtimoiy tarmoqlarda ham kuzatib boring</h6>
                            </div>
                            <ul class="mt-20">
                                <li><a href="https://t.me/qaqnus_academy" target="_blank"><i class="fa fa-telegram"></i></a></li>
                                <li><a href="https://m.facebook.com/105545061997117/" target="_blank"><i class="fa fa-facebook-f" ></i></a></li>
                                <li><a href="https://qaqnusacademy@gmail.com " target="_blank" ><i class="fa fa-google-plus" ></i></a></li>
                                <li><a href="https://www.instagram.com/p/CSte3c3Dvp2/?utm_medium=share_sheet" target="_blank"><i class="fa fa-instagram"></i></a></li>

                               
                            </ul>
                        </div> <!-- footer about -->
                    </div>
                    <div style="margin-left:0px;" class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-link mt-40">
                            <div class="footer-title pb-25">
                                <h6>Sayt Xaritasi</h6>
                            </div>
                            <ul>
                                <li><a href="index-2.php"><i class="fa fa-angle-right"></i>Uy sahifasi</a></li>
                                <li><a href="about.html"><i class="fa fa-angle-right"></i>Biz haqimizda</a></li>
                                <li><a href="courses.php"><i class="fa fa-angle-right"></i>Kurslar</a></li>
                                <li><a href="contact.php"><i class="fa fa-angle-right"></i>Kursda Yozilish</a></li>
                            </ul>
                            
                        </div> <!-- footer link -->
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-address mt-40">
                            <div class="footer-title pb-25">
                                <h6>Biz bilan Bog'lanish</h6>
                            </div>
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-home"></i>
                                    </div>
                                    <div class="cont">
                                        <p>Toshkent</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                    <div class="cont">
                                        <p>+998931774770</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                    <div class="cont">
                                        <p>qaqnusacademy@gmail.com</p>
                                    </div>
                                </li>
                            </ul>
                        </div> <!-- footer address -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer top -->
      
    </footer>
    
    <!--====== FOOTER PART ENDS ======-->
   
    <!--====== BACK TO TP PART START ======-->
    
    <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>
    
    <!--====== BACK TO TP PART ENDS ======-->
   
    
    
    
    
    
    
    
    <!--====== jquery js ======-->
    <script src="../js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="../js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="../js/bootstrap.min.js"></script>
    
    <!--====== Slick js ======-->
    <script src="../js/slick.min.js"></script>
    
    <!--====== Magnific Popup js ======-->
    <script src="../js/jquery.magnific-popup.min.js"></script>
    
    <!--====== Counter Up js ======-->
    <script src="../js/waypoints.min.js"></script>
    <script src="../js/jquery.counterup.min.js"></script>
    
    <!--====== Nice Select js ======-->
    <script src="../js/jquery.nice-select.min.js"></script>
    
    <!--====== Nice Number js ======-->
    <script src="../js/jquery.nice-number.min.js"></script>
    
    <!--====== Count Down js ======-->
    <script src="../js/jquery.countdown.min.js"></script>
    
    <!--====== Validator js ======-->
    <script src="../js/validator.min.js"></script>
    
    <!--====== Ajax Contact js ======-->
    <script src="../js/ajax-contact.js"></script>
    
    <!--====== Main js ======-->
    <script src="../js/main.js"></script>
    
    <!--====== Map js ======-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC3Ip9iVC0nIxC6V14CKLQ1HZNF_65qEQ"></script>
    <script src="../js/map-script.js"></script>

</body>

</html>
