<?php 

session_start();
 
include('../database/connection.php');

if ($con) 
  {

  }
else
	{
		echo "no connection";
	}

 mysqli_select_db($con,'qaqnusakademy');
 $username=$_POST['username'];
 $pass=$_POST['password'];
 $email=$_POST['email'];

 $q="select * from login where username='$username' && password='$pass'";

 $result=mysqli_query($con,$q);
 $num=mysqli_num_rows($result);
 
 if ($num==1)
  {
 	"duplicate data";
 	header('location:../html/registr.html');
 }
 else
 {
 	$qy="insert into login(username,password,email) values('$username','$pass','$email')";
 	mysqli_query($con,$qy);
 	header('location:../html/courses.php');
 }

 ?>