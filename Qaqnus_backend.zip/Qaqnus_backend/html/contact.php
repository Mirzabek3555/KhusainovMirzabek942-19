
<!doctype html>
<html lang="en">
<head>
   
    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!--====== Title ======-->
    <title>Qaqnus Academy</title>
    
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="../images/favicon.png" type="image/png">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="../css/slick.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="../css/animate.css">
    
    <!--====== Nice Select css ======-->
    <link rel="stylesheet" href="../css/nice-select.css">
    
    <!--====== Nice Number css ======-->
    <link rel="stylesheet" href="../css/jquery.nice-number.min.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="../css/magnific-popup.css">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    
    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="../css/font-awesome.min.css">
    
    <!--====== Default css ======-->
    <link rel="stylesheet" href="../css/default.css">
    
    <!--====== Style css ======-->
    <link rel="stylesheet" href="../css/style.css">
    
    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="../css/responsive.css">
  
  
</head>

<body>
   
    <!--====== PRELOADER PART START ======-->
    
    <header id="header-part">
        <div class="navigation">
            <div class="container">
                <div class="row">
                    <div class="col-lg-14 col-md-14 col-sm-14 col-14">
                        <nav class="navbar navbar-expand-lg">
                            <a  class="navbar-brand ; " href="#">
                                <img  style="width: 100px; height: 100px;" src="../images/logoo.png" alt="Logo">
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul class="navbar-nav mr-auto">
    
                                   
                                    <li class="nav-item">
                                        <i class="fa fa-home"></i>
                                        <a class="active" href="index-2.php">Home</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="about.html">Biz Haqimizda</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="courses.php">Kurslar</a>                                        
                                    </li>                                   
                                    <li class="nav-item">
                                        <a href="teachers.html">Bizning Mentorlar</a>
                                    </li>                              
                                    <li class="nav-item">
                                        <a href="contact.php">Kursga Yozilish</a>
                                         
                                    </li>
                                    <li class="nav-item">
                                        <a href="../auth/logout.php">Chiqish</a>
                                         
                                    </li> 
                                </ul>
                            </div>
                        </nav>  
                    </div>
                   
                </div> <!-- row -->
            </div> <!-- container -->
        </div>
        
    </header>
    
    <!--====== HEADER PART ENDS ======-->
   
    <!--====== SEARCH BOX PART START ======-->
    
    <div class="search-box">
        <div class="serach-form">
            <div class="closebtn">
                <span></span>
                <span></span>
            </div>
            <form action="#">
                <input type="text" placeholder="Search by keyword">
                <button><i class="fa fa-search"></i></button>
            </form>
        </div> <!-- serach form -->
    </div>  
  
    <section id="page-banner" class="pt-105 pb-130 bg_cover" data-overlay="8" style="background-image: url(../images/page-banner-6.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-banner-cont">
                        <h2>Kursga Yozilish</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index-2.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Kursga Yozilish</li>
                            </ol>
                        </nav>
                    </div>  <!-- page banner cont -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== PAGE BANNER PART ENDS ======-->
    
    <!--====== CONTACT PART START ======-->
    
    <section id="contact-page" class="pt-90 pb-120 gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="contact-from mt-30">
                        <div class="section-title">
                            <h5>Bog'lanish</h5>
                            <!-- <h2>Keep in touch</h2> -->
                        </div> <!-- section title -->
                        <div class="main-form pt-45">
                            <form id="contact-form" action="../html/contactt.php" method="POST" data-toggle="validator">
                                <div class="row">
                              
                                    
                                    <div class="col-md-6">
                                        <div class="singel-form form-group">
                                            <input name="user_name" type="text" placeholder="Ismingiz" data-error="Name is required." required="required">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form -->
                                    </div>
                                    <div class="col-md-6">
                                        <div class="singel-form form-group">
                                            <input name="email" type="email" placeholder="Email" data-error="Valid email is required." required="required">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form -->
                                    </div>
                                    <div class="col-md-6">
                                        <div class="singel-form form-group">
                                            <input name="cours_name" type="text" placeholder="Kurs" data-error="Subject is required." required="required">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form --> 
                                    </div>
                                    <div class="col-md-6">
                                        <div class="singel-form form-group">
                                            <input name="phone" type="text" placeholder="Telefon raqam " data-error="Phone is required." required="required">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form -->
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="singel-form">
                                            <button type="submit" name="submit" class="main-btn">Yuborish</button>
                                        </div> <!-- singel form -->
                                    </div> <br> <br>

                                    <b style="color: red;">Kursga yozilgan bo'lsangiz Ro'yhatdan O'ting! &nbsp;</b>
                                <a href="../html/registr.html">Ro'yhatdan O'tish</a>
                                </div> <!-- row -->
                            </form>

      
                        </div> <!-- main form -->
                    </div> <!--  contact from -->
                </div>
                <div class="col-lg-5">
                    <div class="contact-address mt-30">
                        <ul>
                            <li>
                                <div class="singel-address">
                                    <div class="icon">
                                        <i class="fa fa-home"></i>
                                    </div>
                                    <div class="cont">
                                        <p>Toshkent</p>
                                    </div>
                                </div> <!-- singel address -->
                            </li>
                            <li>
                                <div class="singel-address">
                                    <div class="icon">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                    <div class="cont">
                                        <p>+998931774770</p>
                                        
                                    </div>
                                </div> <!-- singel address -->
                            </li>
                            <li>
                                <div class="singel-address">
                                    <div class="icon">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                    <div class="cont">
                                        <p>qaqnusacademy@gmail.com</p>
                                        
                                    </div>
                                </div> <!-- singel address -->
                            </li>
                        </ul>
                    </div> <!-- contact address -->
                    <!-- <div class="map mt-30">
                        <div id="contact-map"></div>
                    </div> map -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== CONTACT PART ENDS ======-->
   
    <!--====== FOOTER PART START ======-->
    
    <footer id="footer-part">
        <div class="footer-top pt-20 pb-40">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-about mt-40">
                            <div class="logo">
                                <!-- <a href="#"><img src="images/logo-2.png" alt="Logo"></a> -->
                            </div>
                            <div class="footer-title pb-25">
                                <h6>Bizni ijtimoiy tarmoqlarda ham kuzatib boring</h6>
                            </div>
                            <ul class="mt-20">
                                <li><a href="https://t.me/qaqnus_academy" target="_blank"><i class="fa fa-telegram"></i></a></li>
                                <li><a href="https://m.facebook.com/105545061997117/" target="_blank"><i class="fa fa-facebook-f" ></i></a></li>
                                <li><a href="https://qaqnusacademy@gmail.com " target="_blank" ><i class="fa fa-google-plus" ></i></a></li>
                                <li><a href="https://www.instagram.com/p/CSte3c3Dvp2/?utm_medium=share_sheet" target="_blank"><i class="fa fa-instagram"></i></a></li>

                               
                            </ul>
                        </div> <!-- footer about -->
                    </div>
                    <div style="margin-left:0px;" class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-link mt-40">
                            <div class="footer-title pb-25">
                                <h6>Sayt Xaritasi</h6>
                            </div>
                            <ul>
                                <li><a href="index-2.php"><i class="fa fa-angle-right"></i>Uy sahifasi</a></li>
                                <li><a href="about.html"><i class="fa fa-angle-right"></i>Biz haqimizda</a></li>
                                <li><a href="courses.php"><i class="fa fa-angle-right"></i>Kurslar</a></li>
                                <li><a href="contact.php"><i class="fa fa-angle-right"></i>Kursda Yozilish</a></li>
                            </ul>
                            
                        </div> <!-- footer link -->
                    </div>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                        
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-address mt-40">
                            <div class="footer-title pb-25">
                                <h6>Biz bilan Bog'lanish</h6>
                            </div>
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-home"></i>
                                    </div>
                                    <div class="cont">
                                        <p>Toshkent</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                    <div class="cont">
                                        <p>+998931774770</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fa fa-envelope-o"></i>
                                    </div>
                                    <div class="cont">
                                        <p>qaqnusacademy@gmail.com</p>
                                    </div>
                                </li>
                            </ul>
                        </div> <!-- footer address -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer top -->
      
    </footer>
    
    <!--====== FOOTER PART ENDS ======-->
   
    <!--====== BACK TO TOP PART START ======-->
    
    <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>
    
    <!--====== BACK TO TOP PART ENDS ======-->
    
    
    
    
    
    
    
    <!--====== jquery js ======-->
    <script src="../js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="../js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="../js/bootstrap.min.js"></script>
    
    <!--====== Slick js ======-->
    <script src="../js/slick.min.js"></script>
    
    <!--====== Magnific Popup js ======-->
    <script src="../js/jquery.magnific-popup.min.js"></script>
    
    <!--====== Counter Up js ======-->
    <script src="../js/waypoints.min.js"></script>
    <script src="../js/jquery.counterup.min.js"></script>
    
    <!--====== Nice Select js ======-->
    <script src="../js/jquery.nice-select.min.js"></script>
    
    <!--====== Nice Number js ======-->
    <script src="../js/jquery.nice-number.min.js"></script>
    
    <!--====== Count Down js ======-->
    <script src="../js/jquery.countdown.min.js"></script>
    
    <!--====== Validator js ======-->
    <script src="../js/validator.min.js"></script>
    
    <!--====== Ajax Contact js ======-->
    <script src="../js/ajax-contact.js"></script>
    
    <!--====== Main js ======-->
    <script src="../js/main.js"></script>
    
    <!--====== Map js ======-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC3Ip9iVC0nIxC6V14CKLQ1HZNF_65qEQ"></script>
    <script src="../js/map-script.js"></script>

</body>
</html>
