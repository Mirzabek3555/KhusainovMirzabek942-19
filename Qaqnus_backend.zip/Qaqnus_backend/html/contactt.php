<?php
 $host = "localhost";
 $username = "root";
 $password = "";
 $database = "qaqnusakademy";

$con = mysqli_connect($host, $username, $password,$database);

if( !$con){

    echo "Ulanmadi";
    
}
if(!mysqli_select_db($con,'qaqnusakademy')){
    echo "ulanmadi";
}

$user_name = $_POST['user_name'];
$email = $_POST['email'];
$cours_name = $_POST['cours_name'];
$phone = $_POST['phone'];

$ulash = "INSERT INTO contact (user_name,email,cours_name,phone)  VALUES ('$user_name','$email','$cours_name','$phone')";

if(!mysqli_query($con,$ulash)){
    echo "ayyy";
}
else
{
    echo "inaqu";
}