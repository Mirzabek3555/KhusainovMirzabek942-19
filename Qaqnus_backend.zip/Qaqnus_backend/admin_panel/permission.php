<!DOCTYPE html>
<html lang="en">
<head>
	
<?php
    $title = "Admin";
    include "../admin/includes/header.php";
?>

</head>
<body>
	
<nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
  <a class="navbar-brand text-white" href="#">Qaqnus Academy</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto ">
      <li class="nav-item active">
        <a class="nav-link text-white" href="#"> Uy <span class="sr-only">(current)</span></a>
      </li>
     
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

        <!-- sidebar starts -->

    <div class="container-fluid" style="margin-top: 50px;" >
      <div class="row">
        <div class="col-sm-2 col-md-2 sidebar badge-dark" style="margin:inherit;" id="sidebar" >
         <ul class="list-group text-white sidebar-list">
            <li class="list-group-item  bg-dark "><a href="">Welcome Admin</a></li>
            <li class="list-group-item bg-dark"><a href="">Video Qoshish</a></li>
            <li class="list-group-item bg-dark"><a href="">Manage Comments</a></li>
            <li class="list-group-item bg-dark"><a href="">Foydalanuvchilar</a></li>
            <li class="list-group-item bg-dark"><a href="/admin_panel/admin_page.php">Chiqish</a></li>
            <li class="list-group-item bg-dark" style="height: 400px;"></li>
          </ul>
        </div>

        <div class=" col-md-10">
               <div class="card-header bg-white" style="margin-right: -45px; height: 60px;">
                 <b>Video Qo'shish</b>
                  <button type="btn btn-outline-success" class="btn btn-primary float-right" style="height: 40px;"><a href="../login.php" class="text-white ">Chiqish</a> </button>
                  </div>


            
             <form method="POST" action=""  enctype="multipart/form-data" >

            
          <input type="text" name="username" placeholder="Username" >
          <input type="number" name="course_id" placeholder="Kurs id" >
          <input type="number" name="modul" placeholder="Modul" >


          <input type="submit" name="upload" value="Jo'natish">

         </form>


		   <?php
		   include ('../database/connection.php');
           mysqli_select_db($con, $database);


		   if (isset($_POST['upload'])) {



      
      $modul = $_POST['modul'];
      $username = $_POST['username'];
      $course_id = $_POST['course_id'];


      $sql1 = "INSERT INTO permission ( username, course_id, modul) 
      VALUES('$username' , '$course_id' , '$modul')";
      $res1 = mysqli_query($con, $sql1);
      print_r($res1);
      
			if ($res1==1){
				echo "<h1> Malumot Yuklandi</h1>";
			}
       } else{
          die ('Else ga tushdi bu');
       }
		  ?>

               
</body>
</html>