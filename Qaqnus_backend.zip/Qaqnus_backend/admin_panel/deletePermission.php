<?php
include "../database/connection.php"; 
$id = $_GET['id']; 
$del = mysqli_query($con,"delete from permission where id = '$id'"); 
if($del)
{
    mysqli_close($con);
    header("location:write_kurs.php"); 
    exit;
}else {
    echo "Error deleting record"; 
}
?>