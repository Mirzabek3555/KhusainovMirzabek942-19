<!DOCTYPE html>
<html lang="en">
<head>
	
<?php
    $title = "Admin";
    include "../admin/includes/header.php";
?>
</head>
<body>
	
<nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
  <a class="navbar-brand text-white" href="#">Qaqnus Academy</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto ">
      <li class="nav-item active">
        <a class="nav-link text-white" href="#"> Uy <span class="sr-only">(current)</span></a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
<div class="container-fluid" style="margin-top: 50px;" >
      <div class="row">
        <div class="col-sm-2 col-md-2 sidebar badge-dark" style="margin:inherit;" id="sidebar" >
         <ul class="list-group text-white sidebar-list">
            <li class="list-group-item  bg-dark "><a href="">Welcome Admin</a></li>
            <li class="list-group-item bg-dark"><a href="../admin_panel/manage_videos.php">Video Qoshish</a></li>
            <li class="list-group-item bg-dark"><a href="../admin_panel/write_kurs.php">Kursga Yozilganlar</a></li>
            <li class="list-group-item bg-dark"><a href="../admin_panel/admin_page.php">Foydalanuvchilar</a></li>
            <li class="list-group-item bg-dark"><a href="../admin_panel/admin_page.php">Chiqish</a></li>
            <li class="list-group-item bg-dark" style="height: 400px;"></li>
          </ul>
        </div>  
           

              <!--Kursga ruhsat berilganlar -->
        <div class=" col-md-10">              
            <div class="row ">   
              <div class="col-md-12 "><br>
                <table class="table table-bordered table-danger ml-5 bg-white shodow pl-5 table-responsive" style=" height : 355px;overflow-y: scroll;display: inline-block; width: 1200px;"> 
                
                <h4 style="text-align:center" class="ml-5">Kursga ruhsat berilganlar</h4>  <br>          
                 <thead class="thead-dark">
                  <tr>                
                     <th>N:</th>
                    <th>Username</th>
                    <th >Kurs</th>
                    <th >Modul</th>
                    <th>O'chirish</th>
                     
                  </tr>
                </thead>
                <tbody style="">
                   <?php 
                        include('../database/connection.php');
$sql = "SELECT * FROM permission";
if($result = mysqli_query($con, $sql));                         
while($row = mysqli_fetch_array($result)){          
                   ?> 
                  <tr >
                      <td><?php echo $row['id'];?></td>
                  <td><?php echo $row['username']; ?></td>                    
                    <td ><?php echo $row['course_id']; ?></td>
                    <td><?php echo $row['modul']; ?></td>
                    <td><a href="deletePermission.php?id=<?php echo $row['id']; ?>">Delete</a></td>

                  </tr>                 
                 <?php } ?>
                </tbody>

             </table> 
             <br>   <!--Kursga yozilganlar!!! -->
               <table class="table table-bordered table-danger ml-5 bg-white shodow pl-5 table-responsive" style=" height : 355px;overflow-y: scroll;display: inline-block; width: 1200px;"> 
                
                <h4 style="text-align:center" class="ml-5">Kursga ruhsat so'rab yozilganlar</h4>  <br>          
                 <thead class="thead-dark">
                  <tr>                
                     <th>N:</th>
                    <th>Username</th>
                    <th >Email</th>
                    <th >Kurs</th>
                    <th >Telefon</th>
                    <th>O'chirish</th>
                     
                  </tr>
                </thead>
                <tbody style="">
                   <?php 
                        include('../database/connection.php');
$sql = "SELECT * FROM contact";
if($result = mysqli_query($con, $sql));                         
while($row = mysqli_fetch_array($result)){          
                   ?> 
                  <tr >
                      <td><?php echo $row['id'];?></td>
                  <td><?php echo $row['user_name']; ?></td>                    
                    <td ><?php echo $row['email']; ?></td>
                    <td><?php echo $row['cours_name']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><a href="delete.php?id=<?php echo $row['id']; ?>">Delete</a></td>

                  </tr>                 
                 <?php } ?>
                </tbody>
             </table> 
                <div class = "permission" style="margin-left: 50px; margin-bottom:40px;"> 
                <h4 style="text-align:center" class="ml-5">Foydalanuvchiga ruhsat berish:</h4>     
                  <div class = "permission2">
             <!-- permission -->

             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                 
             <form method="POST" action=""  enctype="multipart/form-data" >

            
            <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Username yozing va shu fodalanuvchiga ruhsat bering!</p>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    <input type="text" name="username" placeholder="Username" >

           <select name="course_id">
              <option value="1">Moliya</option>
              <option value="2">Soglik</option>
              <option value="3">Munosabatlar</option>
              <option value="4">Sh.Rivojlanish</option>
          </select>
             
          <select name="modul" >
              <option value="1">Modul_1</option>
              <option value="2">Modul_2</option>             
          </select>


<input type="submit" name="upload" value="Jo'natish">

</form>
                          </div>

                    

<?php
include ('../database/connection.php');
 mysqli_select_db($con, $database);


if (isset($_POST['upload'])) {




$modul = $_POST['modul'];
$username = $_POST['username'];
$course_id = $_POST['course_id'];


$sql1 = "INSERT INTO permission ( username, course_id, modul) 
VALUES('$username' , '$course_id' , '$modul')";
$res1 = mysqli_query($con, $sql1);


if ($res1==1){
echo "<h3> Malumot Yuklandi</h3>";
}
} else{
 ?>  &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <?php echo  ("Jo'natish bosilmagan yoki malumot yuklanmadi! ");
}
?>  


                  
                </div>

              </div>   
            </div> 
       </div> 
       <!-- Closed div Kursga yozilganlar -->




      </div>       
    </div>    
   
</body>
</html>



   
