<!DOCTYPE html>
<html lang="en">
<head>
	
<?php
    $title = "Admin";
    include "../admin/includes/header.php";
?>
</head>
<body>
	
<nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
  <a class="navbar-brand text-white" href="#">Qaqnus Academy</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto ">
      <li class="nav-item active">
        <a class="nav-link text-white" href="#"> Uy <span class="sr-only">(current)</span></a>
      </li>
     
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>



        <!-- sidebar starts -->

    <div class="container-fluid" style="margin-top: 50px;" >
      <div class="row">
        <div class="col-sm-2 col-md-2 sidebar badge-dark" style="margin:inherit;" id="sidebar" >
         <ul class="list-group text-white sidebar-list">
            <li class="list-group-item  bg-dark "><a href="../admin_panel/admin_page.php">Welcome Admin</a></li>
            <li class="list-group-item bg-dark"><a href="">Video Qoshish</a></li>
            <li class="list-group-item bg-dark"><a href="/admin_panel/write_kurs.php">Kursga Yozilganlar</a></li>
            <li class="list-group-item bg-dark"><a href="../admin_panel/admin_page.php">Foydalanuvchilar</a></li>
            <li class="list-group-item bg-dark"><a href="/admin_panel/admin_page.php">Chiqish</a></li>
            <li class="list-group-item bg-dark" style="height: 400px;"></li>
          </ul>
        </div>

        <div class=" col-md-10">
               <div class="card-header bg-white" style="margin-right: -45px; height: 60px;">
                 <b>Video Qo'shish</b>
                  <button type="btn btn-outline-success" class="btn btn-primary float-right" style="height: 40px;"><a href="../login.php" class="text-white ">Chiqish</a> </button>
                  </div>

            
             <form method="POST" action=""  enctype="multipart/form-data" >

            
          <input type="file" name="file"> 
          <input type="number" name="video_number" placeholder="Video tartib raqami" >

          <select name="course_id">
              <option value="1">Moliya</option>
              <option value="2">Soglik</option>
              <option value="3">Munosabatlar</option>
              <option value="4">Sh.Rivojlanish</option>
          </select>
             
          <select name="modul" >
              <option value="1">Modul_1</option>
              <option value="2">Modul_2</option>             
          </select>

          <select name="type" >
              <option value="1">Bepul</option>
              <option value="0">Pullik</option>             
          </select>

          <input type="submit" name="upload" value="YUKLASH">


		   <?php
		   include ('../database/connection.php');
      
       mysqli_select_db($con, $database);

		   if (isset($_POST['upload'])) {

     // $text = $_POST['video_name'];

			$name = $_FILES['file']['name'];
			$tmp = $_FILES['file']['tmp_name'];

      
			move_uploaded_file($tmp , "videolar/".$name);
    	  

     // $video_name = $_POST['video_name'];
      $number = $_POST['video_number'];
      $course_id = $_POST['course_id'];
      $modul = $_POST['modul'];
     // $path = $_POST['video_name'];
      $type = $_POST['type'];


      $sql1 = "INSERT INTO video ( name, number, course_id, modul, path, type ) 
      VALUES('$name' , '$number' , '$course_id' , '$modul' , '$name' , '$type' )";
      $res1 = mysqli_query($con, $sql1);

				echo "<h1> Video Yuklandi</h1>";
			}
        else{
          print_r ("Videoni yuklab bo'lmadi. Video hajmini tekshiring!");
       }
		  ?>


<script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="../../assets/js/vendor/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
               
</body>
</html>