<?php
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "qaqnusakademy";
    // $port = 3306;

    $con = mysqli_connect($host, $username, $password,$database);
    if ($con) {
            //  echo "connection successful";
    } else {
        echo "no connection";
    }
